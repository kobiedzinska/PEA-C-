#include <iostream>
#include <string>

#include "application/app.h"
#include "utilities/parser/Parser.h"
#include "utilities/SA/SimulatedAnnealing.h"
#include "utilities/structure/Matrix.h"


int main() {
    //app a;
    //a.runConfig();
    ///return 0;
    try {
        std::string file_path = "ftv47.xml"; // Ścieżka do pliku XML
        auto graph = Parser::loadGraphFromXML(file_path);
        Matrix matrix;
        matrix.fromGraph(graph);
        //matrix.printMatrix();

        SimulatedAnnealing sa(matrix,1000.0, 100000, 300.0, 0.9995,0);
        double tempx = sa.calculateInitialTemperature();
        std::cout << tempx << std::endl;
        sa.setTemp(tempx);


        auto [bestPath, bestDistance] = sa.solve();
        std::cout << "Najlepsza znaleziona trasa:\n";
        for (int city : bestPath) {
            std::cout << city << " -> ";
        }
        std::cout << bestPath[0] << std::endl;
        std::cout << "Calkowita dlugosc trasy: " << bestDistance << std::endl;


    } catch (const std::exception& e) {
        std::cerr << "Error: " << e.what() << std::endl;
    }

    return 0;
}
