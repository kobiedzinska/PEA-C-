

#include "SimulatedAnnealing.h"

#include <chrono>

int SimulatedAnnealing::calculateDistance(const std::vector<int> &path) {
    int totalDistance = 0;
    if (path.size() < 2) return totalDistance; // Jeśli za mało wierzchołków, brak podróży

    // Oblicz koszty kolejnych krawędzi
    for (int i = 0; i < path.size() - 1; i++) {
        totalDistance += matrix.getWeight(path[i], path[i + 1]);
    }
    totalDistance += matrix.getWeight(path.back(), path.front()); // dodaje koszt powrotu

    return totalDistance;
}


std::vector<int> SimulatedAnnealing::generateInitialSolution() {
    int MINIMAL = INT_MAX;
    std::vector<int> bestPath;  // We will store the best path here

    for (int i = 0; i < matrix.getSize(); i++) { // Start from every point
        std::vector<bool> visited(matrix.getSize(), false);
        std::vector<int> path;

        int firstPoint = i;
        path.push_back(firstPoint); // Add the first point to the path
        visited[firstPoint] = true; // Mark the first point as visited

        int minimalIndex = 0; // Index of the minimal path weight
        int current = 0;     // Current path weight
        int goVisit = firstPoint;

        while (path.size() < matrix.getSize()) {
            int minimal = INT_MAX; // Minimal path weight
            for (int j = 0; j < matrix.getSize(); j++) { // Visit other points
                if (j != goVisit && !visited[j]) {

                    if (matrix.getWeight(goVisit, j) < minimal) {
                        minimal = matrix.getWeight(goVisit, j);
                        minimalIndex = j;
                    }
                }
            }
            path.push_back(minimalIndex);
            visited[minimalIndex] = true;
            current += minimal;
            goVisit = minimalIndex;
        }
        current += matrix.getWeight(goVisit, firstPoint); // Close the path

        if (current < MINIMAL) {
            MINIMAL = current;
            bestPath = path; // Update the best path
        }
    }

    return bestPath;
}

// Metoda 0: Invert
std::vector<int> SimulatedAnnealing::generateNeighborInvert(const std::vector<int> &path) {
    std::vector<int> alterPath = path;
    int size = path.size();

    // Wybierz dwa różne punkty
    std::uniform_int_distribution<> gen1(0, size - 2);
    int i = gen1(GEN);
    std::uniform_int_distribution<> gen2(i + 1, size - 1);
    int j = gen2(GEN);

    // Odwróć segment między i a j
    std::reverse(alterPath.begin() + i, alterPath.begin() + j + 1);

    return alterPath;
}
// Metoda 1: Select - zamiana dwóch elementów miejscami
std::vector<int> SimulatedAnnealing::generateNeighborSelect(const std::vector<int> &path) {
    std::vector<int> alterPath = path;
    int size = path.size();

    // Wybierz dwa różne punkty
    std::uniform_int_distribution<> gen(0, size - 1);
    int i = gen(GEN);
    int j;
    do {
        j = gen(GEN);
    } while (i == j);

    // Zamień miejscami elementy
    std::swap(alterPath[i], alterPath[j]);

    return alterPath;
}
// Metoda 2: Insert - wstawienie elementu w nowe miejsce
std::vector<int> SimulatedAnnealing::generateNeighborInsert(const std::vector<int> &path) {
    std::vector<int> alterPath = path;
    int size = path.size();

    // Wybierz element do przeniesienia i nową pozycję
    std::uniform_int_distribution<> gen(0, size - 1);
    int from = gen(GEN);
    int to;
    do {
        to = gen(GEN);
    } while (from == to);

    // Przenieś element
    if (from < to) {
        std::rotate(alterPath.begin() + from,
                   alterPath.begin() + from + 1,
                   alterPath.begin() + to + 1);
    } else {
        std::rotate(alterPath.begin() + to,
                   alterPath.begin() + from,
                   alterPath.begin() + from + 1);
    }

    return alterPath;
}

std::vector<int> SimulatedAnnealing::generateNeighbor(const std::vector<int> &path, int strategy) {
    switch(strategy) {
        case 0:
            return generateNeighborInvert(path);
        case 1:
            return generateNeighborSelect(path);
        case 2:
            return generateNeighborInsert(path);
        default:
            // Losowy wybór strategii
                std::uniform_int_distribution<> gen(0, 2);
        return generateNeighbor(path, gen(GEN));
    }
}


std::pair<std::vector<int>, int> SimulatedAnnealing::solve() {
    auto startTime = std::chrono::steady_clock::now();  // Zaczynamy liczyć czas

    std::vector<int> bestPath = currentPath;
    double currentDistance = calculateDistance(currentPath);    // Liczymy aktualny "stan energii" czyli koszt ścieżki
    double bestDistance = currentDistance;
    double temperature = initialTemperature;

    initialCost = currentDistance;  // (do zapisania wyników)

    std::uniform_real_distribution<> r(0.0, 1.0); // random value in the range [0, 1)

    GEN.seed(std::random_device{}());

    //int iterationCount = 0;
    for (int iter = 0; iter < maxIterations && temperature > 0.1; iter++) {
        //iterationCount++;

        auto currentTime = std::chrono::steady_clock::now();
        double elapsedSeconds = std::chrono::duration<double>(currentTime - startTime).count();

        if (elapsedSeconds >= timeLimit) {  // Sprawdzamy czy nie przekroczyliśmy limitu czasu
            std::cout << "Osiagnieto limit czasu (" << timeLimit << " sekund)\n";
            break;
        }

        std::vector<int> neighborPath = generateNeighbor(currentPath, strategy); // Generujemy podobne rozwiązanie
        double neighborDistance = calculateDistance(neighborPath);  // Obliczamy koszt nowej ścieżki

        double delta = neighborDistance - currentDistance;  // Obliczamy różnicę ścieżek deltaE

        if (delta < 0 || r(GEN) < exp(-delta / temperature*5  )) { // Jeśli wynik spełnia nasze warunki

            currentPath = neighborPath;
            currentDistance = neighborDistance;

            if (currentDistance < bestDistance) {   // sprawdzamy czy wynik jest lepszy od aktualnego najlepszego
                bestDistance = currentDistance;
                bestPath = currentPath;
            }
        }

        temperature = a * temperature; // Schładzamy temoeraturę
        // można zmieniać

        if (iter % 1000 == 0) { // Co 1000 iteracji sprawdzamy temperaturę i wynik
            std::cout << "Iteracja " << iter << ": Temperatura = " << temperature
                     << ", Najlepsza odleglosc = " << bestDistance << std::endl;
        }
    }
    //std::cout << "Liczba wykonanych iteracji: " << iterationCount << std::endl;

    auto endTime = std::chrono::steady_clock::now();
    double totalTime = std::chrono::duration<double>(endTime - startTime).count();
    std::cout << "Calkowity czas wykonania: " << totalTime << " sekund\n";

    return {bestPath, bestDistance};    // zwracamy najlepszą ścieżkę i jej koszt
}

int SimulatedAnnealing::getInitialCost() {
    return initialCost;
}

double SimulatedAnnealing::calculateInitialTemperature() {
    const int NUM_SAMPLES = 100;  // liczba próbek do zbadania
    const double TARGET_ACCEPTANCE_RATE = 0.8;  // docelowe prawdopodobieństwo akceptacji na początku

    std::vector<double> deltaCosts;
    deltaCosts.reserve(NUM_SAMPLES);

    // Generuj losowe ruchy i zapisuj zmiany kosztu
    currentPath = generateInitialSolution();
    double currentCost = calculateDistance(currentPath);

    std::cout << "Kalkulacja temperatury poczatkowej...\n";
    std::cout << "Zbieranie " << NUM_SAMPLES << " probek zmian kosztu...\n";

    for (int i = 0; i < NUM_SAMPLES; i++) {
        // Wygeneruj sąsiednie rozwiązanie
        std::vector<int> neighborPath = generateNeighbor(currentPath, strategy);
        double neighborCost = calculateDistance(neighborPath);

        // Zapisz różnicę kosztu (tylko dodatnie zmiany - pogorszenia rozwiązania)
        double deltaCost = neighborCost - currentCost;
        if (deltaCost > 0) {
            deltaCosts.push_back(deltaCost);
        }
    }

    if (deltaCosts.empty()) {
        std::cout << "Uwaga: Nie znaleziono pogorszajacych ruchow. Uzywam domyslnej temperatury.\n";
        return 1000.0;  // wartość domyślna
    }

    // Oblicz średnią zmianę kosztu
    double avgDelta = 0.0;
    for (double delta : deltaCosts) {
        avgDelta += delta;
    }
    avgDelta /= deltaCosts.size();

    // Oblicz temperaturę początkową
    // T = -avgDelta / ln(p), gdzie p to docelowe prawdopodobieństwo akceptacji
    double initialTemp = -avgDelta / std::log(TARGET_ACCEPTANCE_RATE);

    std::cout << "Statystyki probkowania:\n";
    std::cout << "- Liczba pogorszajacych ruchow: " << deltaCosts.size() << "\n";
    std::cout << "- Srednia zmiana kosztu: " << avgDelta << "\n";
    std::cout << "- Obliczona temperatura poczatkowa: " << initialTemp << "\n";

    return initialTemp;
}

void SimulatedAnnealing::setTemp(double temp) {
    this->initialTemperature = temp;
}

